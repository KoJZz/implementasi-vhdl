#include <stdio.h>
#include <string.h>
#include <stdlib.h> // Required for strtol
#include <conio.h> // Required for _getch() on Windows
#include "crypto_hash.h"
#include "api.h"

// Define a maximum size for the input string (e.g., 2048 hex chars = 1024 bytes)
#define MAX_HEX_INPUT_LEN 2048

/**
 * @brief Converts a hexadecimal string to a byte array.
 * * @param hex_string The input string (e.g., "0001FF").
 * @param out_bytes The output buffer for the resulting bytes.
 * @param max_len The maximum length of the output buffer.
 * @return long The actual number of bytes converted, or -1 for error.
 */
long hex_to_bytes(const char *hex_string, unsigned char *out_bytes, long max_len) {
    long len = strlen(hex_string);
    
    // Check if the input length is even (every byte needs two hex characters)
    if (len % 2 != 0) {
        fprintf(stderr, "Error: Hex input length must be even.\n");
        return -1; 
    }
    
    long byte_len = len / 2;

    // Check if the resulting byte array fits in the buffer
    if (byte_len > max_len) {
        fprintf(stderr, "Error: Input is too long.\n");
        return -1; 
    }

    for (long i = 0; i < byte_len; i++) {
        // Read two hex characters (e.g., '0' and 'A')
        char hex_byte[3];
        hex_byte[0] = hex_string[2 * i];
        hex_byte[1] = hex_string[2 * i + 1];
        hex_byte[2] = '\0'; // Null-terminate for strtol

        // Convert the two hex chars to a single byte (base 16)
        out_bytes[i] = (unsigned char)strtol(hex_byte, NULL, 16);
    }
    return byte_len;
}

/* * Function: read_binary_input
 * Logic: Reads generic bytes until EOF. 
 * Critical: Updates the 'out_len' variable so the caller knows the size.
 */
unsigned char* read_binary_input(size_t *out_len) {
    size_t capacity = 16;
    size_t count = 0;
    int ch;

    unsigned char *buffer = malloc(capacity);
    if (!buffer) return NULL;

    while ((ch = getchar()) != EOF) {
        buffer[count++] = (unsigned char)ch;

        if (count == capacity) {
            capacity *= 2;
            unsigned char *temp = realloc(buffer, capacity);
            if (!temp) {
                free(buffer);
                return NULL;
            }
            buffer = temp;
        }
    }

    // UPDATE THE CALLER'S LENGTH VARIABLE
    *out_len = count; 
    
    return buffer;
}

/*
 * Function: binary_to_hex
 * Logic: Iterates exactly 'len' times. 
 * Note: Returns a normal string because "00" (hex) is safe to print.
 */
// char* binary_to_hex(const unsigned char *data, size_t len) {
//     if (!data || len == 0) {
//         // Return an empty string if input is empty
//         char *empty = malloc(1);
//         if (empty) empty[0] = '\0';
//         return empty; 
//     }

//     char *output = malloc((len * 2) + 1);
//     if (!output) return NULL;

//     for (size_t i = 0; i < len; i++) {
//         sprintf(output + (i * 2), "%02X", data[i]);
//     }
    
//     output[len * 2] = '\0'; // Null terminate the hex string
//     return output;
// }

// --- Helper to convert to Hex string ---
char* binary_to_hex(const unsigned char *data, size_t len) {
    char *output = malloc((len * 2) + 1);
    if (!output) return NULL;
    for (size_t i = 0; i < len; i++) {
        sprintf(output + (i * 2), "%02X", data[i]);
    }
    output[len * 2] = '\0';
    return output;
}

/* * Function: read_until_ctrl_z
 * Returns: A pointer to the raw data buffer.
 * Updates: *out_len with the size.
 */
unsigned char* read_until_ctrl_z(size_t *out_len) {
    size_t capacity = 16;
    size_t count = 0;
    int ch;
    
    // Allocate initial memory
    unsigned char *buffer = malloc(capacity);
    if (!buffer) return NULL;

    printf("Input active. Type text. Press Ctrl+Z to finish instantly.\n> ");

    while (1) {
        // _getch reads the keystroke immediately (no Enter needed)
        ch = _getch();

        // CHECK 1: Is it Ctrl+Z? (ASCII 26)
        if (ch == 26) {
            break; // Stop the loop immediately
        }

        // CHECK 2: Is it Ctrl+C? (ASCII 3) - Safety abort
        if (ch == 3) {
            free(buffer);
            printf("\nAborted.\n");
            exit(1);
        }

        // CHECK 3: Is it 'Enter'?
        // Windows sends '\r' (13) for Enter. We usually want to store '\n' (10).
        if (ch == '\r') {
            ch = '\n';
            printf("\n"); // Move cursor down on screen
        } else {
            printf("%c", ch); // Echo character to screen so you see what you type
        }

        // Store the character
        buffer[count++] = (unsigned char)ch;

        // Resize if full
        if (count == capacity) {
            capacity *= 2;
            unsigned char *temp = realloc(buffer, capacity);
            if (!temp) {
                free(buffer);
                return NULL;
            }
            buffer = temp;
        }
    }

    printf("\n[Input Captured]\n");
    *out_len = count;
    return buffer;
}



// int main() {
//     size_t len = 0;
    
//     // 1. Read input using the Windows-friendly method
//     unsigned char *data = read_until_ctrl_z(&len);
    
//     if (data) {
//         // 2. Convert to Hex
//         char *hex = binary_to_hex(data, len);
        
//         printf("Hex Output: %s\n", hex);
        
//         free(hex);
//         free(data);
//     }
//     return 0;
// }

int main() {
    size_t data_length = 0; // We need this variable to track the size

    int choice;
    printf("Apakah kamu ingin menggunakan HEX (1) atau ASCII (2) [1/2]");
    scanf("%d", &choice);

    // 1. CALL THE FUNCTION
    // We pass the ADDRESS (&) of data_length so the function can update it.
    // unsigned char *raw_data = read_binary_input(&data_length);
    unsigned char *raw_data = read_until_ctrl_z(&data_length);

    if (!raw_data) {
        fprintf(stderr, "Memory allocation failed.\n");
        return 1;
    }

    // 2. CONVERT TO HEX
    // We pass the length explicitly because raw_data might contain \0
    char *hex_string = binary_to_hex(raw_data, data_length);

    if (!hex_string) {
        free(raw_data);
        return 1;
    }

    

    int CRYPTO_BYTES;
    printf("Masukkan panjang output hex: \n> ");
    scanf("%d", &CRYPTO_BYTES);

    unsigned long long input_len = (unsigned long long)data_length; 
    const unsigned char* input_message = raw_data;

    // 3. Definisikan buffer output (sesuai CRYPTO_BYTES dari api.h)
    unsigned char output_hash[CRYPTO_BYTES]; 

    // 4. Panggil fungsi hash
    int result = crypto_hash(output_hash, input_message, input_len, CRYPTO_BYTES);

    if (result == 0) {
        printf(" Hashing Berhasil!\n");
        
        // Cetak Input
        printf("Input Bytes (%llu bytes): 0x%s\n", input_len, hex_string);
        // printf("Input Bytes (%llu bytes): 0x", input_len);
        // for (unsigned long long i = 0; i < input_len; i++) {
        //     printf("%02x", hex_string[i]);
        // }
        // printf("\n");

        // Cetak Hash Output
        printf("Output Hash (%d bytes): 0x", CRYPTO_BYTES);
        for (int i = 0; i < CRYPTO_BYTES; i++) {
            printf("%02x", output_hash[i]);
        }
        printf("\n");
    } else {
        printf(" Hashing Gagal (Kode: %d)\n", result);
    }

    // 4. CLEANUP
    free(raw_data);
    free(hex_string);

    return 0;
}

// ... (Continued from above)

// int main() {
//     // Buffer to hold the user's raw hex string input
//     char hex_input[MAX_HEX_INPUT_LEN + 1]; 
    
//     // Buffer to hold the converted raw bytes (Max half the size of hex_input)
//     unsigned char input_data[MAX_HEX_INPUT_LEN / 2]; 
    
//     // 1. Dapatkan input dari pengguna
//     printf("Masukkan data hex yang akan di-hash (cth: 0001AFFE): \n> ");
//     // Menggunakan scanf untuk membaca string tanpa spasi hingga newline
//     if (scanf("%s", hex_input) != 1) {
//         fprintf(stderr, "Error reading input.\n");
//         return 1;
//     }



//     // GAUSAH DIUBAH
//     int CRYPTO_BYTES;
//     printf("Masukkan panjang output hex: \n> ");
//     scanf("%d", &CRYPTO_BYTES);

//     // 2. Konversi string hex menjadi byte array
//     long converted_len = hex_to_bytes(hex_input, input_data, sizeof(input_data));

//     if (converted_len < 0) {
//         // Error message already printed in hex_to_bytes
//         return 1;
//     }

//     unsigned long long input_len = (unsigned long long)converted_len; 
//     const unsigned char* input_message = input_data;

//     // 3. Definisikan buffer output (sesuai CRYPTO_BYTES dari api.h)
//     unsigned char output_hash[CRYPTO_BYTES]; 

//     // 4. Panggil fungsi hash
//     int result = crypto_hash(output_hash, input_message, input_len, CRYPTO_BYTES);

//     if (result == 0) {
//         printf(" Hashing Berhasil!\n");
        
//         // Cetak Input
//         printf("Input Bytes (%llu bytes): 0x", input_len);
//         for (unsigned long long i = 0; i < input_len; i++) {
//             printf("%02x", input_data[i]);
//         }
//         printf("\n");

//         // Cetak Hash Output
//         printf("Output Hash (%d bytes): 0x", CRYPTO_BYTES);
//         for (int i = 0; i < CRYPTO_BYTES; i++) {
//             printf("%02x", output_hash[i]);
//         }
//         printf("\n");
//     } else {
//         printf(" Hashing Gagal (Kode: %d)\n", result);
//     }

//     return 0;
//     // GAUSAH DIUBAH
// }