#ifndef CRYPTO_HASH_H
#define CRYPTO_HASH_H

#include <stdint.h>

// Deklarasi fungsi hashing utama (yang ada di hash.c)
int crypto_hash(unsigned char* out, 
                const unsigned char* in,
                unsigned long long len,int CRYPTO_BYTES);

#endif // CRYPTO_HASH_H