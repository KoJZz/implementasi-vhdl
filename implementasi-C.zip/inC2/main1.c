#include <stdio.h>
#include <string.h>
#include <stdlib.h> 

// Assuming these are available from your crypto library environment
#include "crypto_hash.h"
#include "api.h"

// Define a maximum size for the input string (e.g., 2048 hex chars)
#define MAX_INPUT_STRING_LEN 2048
// Define maximum size for the resulting byte array (half of the max hex string length)
#define MAX_BYTE_DATA_LEN (MAX_INPUT_STRING_LEN / 2)


/**
 * @brief Converts a hexadecimal string to a byte array.
 * @param hex_string The input string (e.g., "0001FF").
 * @param out_bytes The output buffer for the resulting bytes.
 * @param max_len The maximum length of the output buffer.
 * @return long The actual number of bytes converted, or -1 for error.
 */
long hex_to_bytes(const char *hex_string, unsigned char *out_bytes, long max_len) {
    long len = strlen(hex_string);
    
    // Check if the input length is even (every byte needs two hex characters)
    if (len % 2 != 0) {
        fprintf(stderr, "Error: Panjang input Hex harus genap.\n");
        return -1; 
    }
    
    long byte_len = len / 2;

    // Check if the resulting byte array fits in the buffer
    if (byte_len > max_len) {
        fprintf(stderr, "Error: Input terlalu panjang.\n");
        return -1; 
    }

    for (long i = 0; i < byte_len; i++) {
        // Read two hex characters (e.g., '0' and 'A')
        char hex_byte[3];
        hex_byte[0] = hex_string[2 * i];
        hex_byte[1] = hex_string[2 * i + 1];
        hex_byte[2] = '\0'; // Null-terminate for strtol

        // Convert the two hex chars to a single byte (base 16)
        char *endptr;
        long val = strtol(hex_byte, &endptr, 16);

        // Basic check for conversion error (invalid character)
        if (*endptr != '\0' || val < 0 || val > 255) {
             fprintf(stderr, "Error: Karakter Hex tidak valid terdeteksi: %c%c\n", hex_byte[0], hex_byte[1]);
             return -1;
        }

        out_bytes[i] = (unsigned char)val;
    }
    return byte_len;
}


int main() {
    int input_type = 0; // 1 for ASCII, 2 for Hex
    int hash_output_bytes; 
    
    // Buffer for the raw input string (either ASCII or Hex string)
    char input_string[MAX_INPUT_STRING_LEN + 2]; 
    // Buffer for the data bytes (used directly for ASCII, or for converted Hex)
    unsigned char input_data_bytes[MAX_BYTE_DATA_LEN]; 
    
    // Pointers and length that will be passed to crypto_hash
    const unsigned char* input_message = NULL;
    unsigned long long message_len = 0;


    printf("====================================================\n");
    printf("     Generic Hashing Utility (Flexible Input)\n");
    printf("====================================================\n");

    // --- 1. Get Input Type ---
    printf("Pilih tipe input:\n");
    printf("1. Teks ASCII (Contoh: Hello World)\n");
    printf("2. String Hex (Contoh: 48656C6C6F)\n> ");
    if (scanf("%d", &input_type) != 1 || (input_type != 1 && input_type != 2)) {
        fprintf(stderr, "Error: Pilihan tipe input tidak valid.\n");
        return 1;
    }
    
    // Clear the input buffer from the newline character left by scanf(%d)
    int c;
    while ((c = getchar()) != '\n' && c != EOF);

    // --- 2. Get Input Message ---
    printf("Masukkan data (%s): Tekan Enter untuk input kosong (0-byte).\n> ", (input_type == 1) ? "ASCII" : "Hex");
    
    // Use fgets for safer reading of the input string
    if (fgets(input_string, sizeof(input_string), stdin) == NULL) {
        fprintf(stderr, "Error reading input.\n");
        return 1;
    }

    // Remove the trailing newline character added by fgets, if present
    size_t temp_len = strlen(input_string);
    if (temp_len > 0 && input_string[temp_len - 1] == '\n') {
        input_string[temp_len - 1] = '\0';
        temp_len--; // Decrease length as the newline is no longer part of the data
    }

    // --- Cek input kosong (sekarang diperbolehkan, sehingga pemeriksaan dihilangkan) ---
    // If temp_len is 0, the program will proceed with a message_len of 0.
    
    // --- 3. Process Input based on Type ---
    if (input_type == 1) { // ASCII
        input_message = (const unsigned char*)input_string;
        message_len = (unsigned long long)temp_len;
    } else { // Hex
        // Convert the Hex string into the raw byte array
        long converted_len = hex_to_bytes(input_string, input_data_bytes, sizeof(input_data_bytes));

        // If the hex string was empty (temp_len = 0), converted_len will be 0, which is fine.
        if (converted_len < 0) {
            // Error message already printed in hex_to_bytes
            return 1;
        }
        input_message = input_data_bytes;
        message_len = (unsigned long long)converted_len;
    }
    
    // --- 4. Get hash output size ---
    printf("Masukkan panjang output hash (dalam bytes, cth: 32 untuk SHA-256):\n> ");
    // Ensure that scanf only reads an integer and the newline is cleared from the buffer
    if (scanf("%d", &hash_output_bytes) != 1 || hash_output_bytes <= 0) {
        fprintf(stderr, "Error: Panjang output hash tidak valid.\n");
        return 1;
    }

    // --- 5. Define output buffer ---
    unsigned char *output_hash = (unsigned char *)malloc(hash_output_bytes);
    if (output_hash == NULL) {
        fprintf(stderr, "Error: Gagal mengalokasikan memori untuk output hash.\n");
        return 1;
    }

    // --- 6. Call the hash function ---
    int result = crypto_hash(output_hash, input_message, message_len, hash_output_bytes);

    printf("\n----------------------------------------------------\n");
    if (result == 0) {
        printf(" Hashing Berhasil!\n");
        
        // Print the Input Type
        if (input_type == 1) {
            printf("Input Teks ASCII: \"%s\"\n", input_string);
        } else {
             printf("Input String Hex: \"%s\"\n", input_string);
        }

        // Print Input in Hex Bytes Format
        printf("Input Bytes (%llu bytes): 0x", message_len);
        // Only print bytes if message_len > 0
        for (unsigned long long i = 0; i < message_len; i++) {
            printf("%02x", input_message[i]);
        }
        printf("\n");

        // Print Hash Output (Hex)
        printf("Output Hash (%d bytes): 0x", hash_output_bytes);
        for (int i = 0; i < hash_output_bytes; i++) {
            printf("%02x", output_hash[i]);
        }
        printf("\n");
    } else {
        printf(" Hashing Gagal (Kode: %d)\n", result);
    }
    printf("----------------------------------------------------\n");

    // Free the dynamically allocated memory
    free(output_hash); 

    return 0;
}